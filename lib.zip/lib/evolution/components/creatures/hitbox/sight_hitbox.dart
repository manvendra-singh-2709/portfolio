import 'package:flame/collisions.dart';
import 'package:portfolio/evolution/components/creatures/creature.dart';
import 'package:vector_math/vector_math.dart';

class SightHitbox extends CircleHitbox {
  SightHitbox({required this.creature, required double radius}) : super(radius: radius);

  final Creature creature;

  @override
  void onCollisionStart(Set<Vector2> intersectionPoints, ShapeHitbox other) {
    super.onCollisionStart(intersectionPoints, other);

    creature.onSightDetected(other);
  }
}