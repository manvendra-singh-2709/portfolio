import 'package:flame/collisions.dart';
import 'package:portfolio/evolution/components/creatures/creature.dart';
import 'package:vector_math/vector_math.dart';

class BodyHitbox extends RectangleHitbox {
  BodyHitbox({
    required this.creature,
    required Vector2 size,
  }) : super(size: size);

  final Creature creature;

  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    ShapeHitbox other,
  ) {
    super.onCollisionStart(intersectionPoints, other);

    creature.onBodyCollision(other);
  }
}